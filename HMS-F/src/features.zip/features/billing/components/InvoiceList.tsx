import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { Button } from "@/components/ui/button";
import {
  Calendar,
  Search,
  Plus,
  ChevronRight,
  Download,
  FileText,
} from "lucide-react";

import { useIsAdmin, useIsAccountant } from "@/store/useAuthStore";
import { StatusBadge } from "@/components/shared/DesignSystem";
import { format } from "date-fns";
import { useInvoices, useDownloadPdf } from "@/hooks/useBilling";

interface Invoice {
  id: number;
  patientName: string;
  createdAt?: string;
  totalAmount?: number;
  paidAmount?: number;
  status: "PAID" | "PARTIAL" | "PENDING" | string;
}

interface InvoiceListProps {
  onViewDetails: (id: number) => void;
  onAddInvoice: () => void;
}

export function InvoiceList({
  onViewDetails,
  onAddInvoice,
}: InvoiceListProps) {
  const { data, isLoading, isError, refetch } = useInvoices();
  const { mutate: downloadPdf, isPending } = useDownloadPdf();

  const items: Invoice[] = data?.data ?? [];

  const isAdmin = useIsAdmin();
  const isAccountant = useIsAccountant();

  const getStatusVariant = (
    status: string
  ): "info" | "success" | "warning" | "default" => {
    switch (status) {
      case "PAID":
        return "success";
      case "PARTIAL":
        return "warning";
      case "PENDING":
        return "info";
      default:
        return "default";
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return isNaN(date.getTime())
      ? "N/A"
      : format(date, "MMM dd, yyyy");
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-center text-destructive p-8 bg-destructive/5 rounded-xl border border-destructive/10">
        <p>Failed to load invoices. Please try again.</p>
        <button
          onClick={() => refetch()}
          className="mt-4 px-4 py-2 border rounded hover:bg-destructive/10 transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="text-center text-muted-foreground p-8">
        No records found.
      </div>
    );
  }

  return (
    <Card className="shadow-smooth border-none bg-background/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle className="text-xl font-bold">
              Billing & Invoices
            </CardTitle>
            <CardDescription>
              Manage patient billing, payments, and financial history
            </CardDescription>
          </div>

          {(isAdmin || isAccountant) && (
            <Button
              onClick={onAddInvoice}
              className="shrink-0 gap-2 shadow-glow"
            >
              <Plus className="h-4 w-4" />
              Create Invoice
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Search */}
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            placeholder="Search by invoice ID or patient..."
            className="flex h-10 w-full rounded-md border border-muted-foreground/20 bg-background/50 px-9 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>

        {/* Table */}
        <div className="rounded-xl border overflow-hidden border-muted-foreground/10 bg-background/40">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[100px]">Invoice</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Issued Date</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              {items.map((invoice) => (
                <TableRow
                  key={invoice.id}
                  className="group transition-colors"
                >
                  <TableCell className="font-mono text-xs font-semibold">
                    INV-
                    {String(invoice.id ?? "")
                      .padStart(5, "0")}
                  </TableCell>

                  <TableCell className="font-medium">
                    {invoice.patientName || "N/A"}
                  </TableCell>

                  <TableCell>
                    <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                      <Calendar className="h-3.5 w-3.5" />
                      {formatDate(invoice.createdAt)}
                    </div>
                  </TableCell>

                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-bold text-sm">
                        Rs.{" "}
                        {(invoice.totalAmount ?? 0).toLocaleString()}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        Paid: Rs.{" "}
                        {(invoice.paidAmount ?? 0).toLocaleString()}
                      </span>
                    </div>
                  </TableCell>

                  <TableCell>
                    <StatusBadge
                      variant={getStatusVariant(invoice.status)}
                    >
                      {invoice.status}
                    </StatusBadge>
                  </TableCell>

                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      {(isAdmin || isAccountant) && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-primary"
                          onClick={() =>
                            downloadPdf(invoice.id)
                          }
                          disabled={isPending}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      )}

                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() =>
                          onViewDetails(invoice.id)
                        }
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}